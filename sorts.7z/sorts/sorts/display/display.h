#include <stdio.h>
#include <stdlib.h>
#ifndef DISPLAY_H
#define DISPLAY_H

int print_list(int *arr, size_t length);

#endif // DISPLAY_H
