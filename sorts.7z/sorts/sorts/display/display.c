#include <stdio.h>
#include <stdlib.h>
#include "display.h"

int print_list(int *arr, size_t length) {
    int i = 0;
    for (i = 0; i < length; i++)
        printf("%d ", arr[i]);
    printf("\n");
    return 0;
}
