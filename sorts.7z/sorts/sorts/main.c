#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "display/display.h"
#include "merge/inplacemerge.h"

int main()
{
    int arr[] = {9,8,7,6,5,4,3,2,1,0};
    size_t length = sizeof(arr)/sizeof(arr[0]);
    inplace_merge_sort(arr, 0, length);
    return 0;
}
