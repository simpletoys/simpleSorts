#include <stdlib.h>
#ifndef BOTTOMUPMERGE_H
#define BOTTOMUPMERGE_H

int bottomup_merge_sort(int *arr, size_t length);

#endif // BOTTOMUPMERGE_H
