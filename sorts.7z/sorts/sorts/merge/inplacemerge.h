#ifndef INPLACEMERGE_H
#define INPLACEMERGE_H

int inplace_merge_sort(int *arr, int from, int to);

#endif // INPLACEMERGE_H
