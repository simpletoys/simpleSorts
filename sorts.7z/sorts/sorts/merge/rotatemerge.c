#include <stdlib.h>
#include <math.h>
#include "rotatemerge.h"
#include "../display/display.h"

static int flip(int *arr, size_t from, size_t to);
static int rotate_merge(int *arr, int from, int mid, int to, size_t length);

static int flip(int *arr, size_t from, size_t to)
{
    int ptr1 = from;
    int ptr2 = to - 1;
    int tmp;
    while (ptr1 < ptr2) {
        tmp = arr[ptr1];
        arr[ptr1] = arr[ptr2];
        arr[ptr2] = tmp;
        ptr1++;
        ptr2--;
    }
    return 0;
}

static int rotate_merge(int *arr, int from, int mid, int to, size_t length)
{
    int ptr1 = floor((from + mid) / 2);
    int ptr2 = mid;
    while (ptr2 < to && arr[ptr2] <= arr[ptr1])
        ptr2++;
    flip(arr, ptr1, mid);
    print_list(arr, length);
    flip(arr, mid, ptr2);
    print_list(arr, length);
    flip(arr, ptr1, ptr2);
    print_list(arr, length);
    mid = ptr1 + ptr2 - mid;
    if (from == mid || mid == to)
        return 0;
    return rotate_merge(arr, from, ptr1, mid, length)
         + rotate_merge(arr, mid, ptr2, to, length);
}

int rotate_merge_sort(int *arr, size_t length)
{
    int num = 1;
    while (num * 2 < length)
        num *= 2;
    int i;
    int from;
    int mid;
    int to;
    while (num >= 1) {
        for (i = 0; i < num; i++) {
            from = floor(i * length / num);
            to = floor((i + 1) * length / num);
            mid = floor((from + to) / 2);
            rotate_merge(arr, from, mid, to, length);
        }
        num /= 2;
    }
    return 0;
}
