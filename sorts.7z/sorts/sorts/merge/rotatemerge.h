#include <stdlib.h>
#ifndef ROTATEMERGE_H
#define ROTATEMERGE_H

int rotate_merge_sort(int *arr, size_t length);

#endif // ROTATEMERGE_H
