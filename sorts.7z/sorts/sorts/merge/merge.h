#include <stdlib.h>
#ifndef MERGE_H
#define MERGE_H

int merge_sort(int *arr, int from, int to, size_t length);

#endif // MERGE_H
