#include <math.h>
#include "inplacemerge.h"

static int inplace_merge(int *arr, int from, int mid, int to);

static int inplace_merge(int *arr, int from, int mid, int to)
{
    int ptr1 = from;
    int ptr2 = mid;
    int i;
    int tmp;
    while (ptr1 < ptr2 && ptr2 < to) {
        if (arr[ptr1] <= arr[ptr2])
            ptr1++;
        else {
            for (i = ptr2; i > ptr1; i--) {
                tmp = arr[i];
                arr[i] = arr[i-1];
                arr[i-1] = tmp;
            }
            ptr2++;
        }
    }
    return 0;
}

int inplace_merge_sort(int *arr, int from, int to)
{
    if (to - from <= 1)
        return 0;
    int mid = floor((from + to) / 2);
    inplace_merge_sort(arr, from, mid);
    inplace_merge_sort(arr, mid, to);
    inplace_merge(arr, from, mid, to);
}
