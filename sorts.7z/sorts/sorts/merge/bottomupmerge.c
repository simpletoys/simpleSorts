#include <stdlib.h>
#include <math.h>
#include "bottomupmerge.h"
#include "../display/display.h"

static int merge(int *arr, int from, int mid, int to, size_t length);

static int merge(int *arr, int from, int mid, int to, size_t length)
{
    int *aux = (int*)calloc(to - from, sizeof(int));
    int ptr1 = from;
    int ptr2 = mid;
    int wrtptr = 0;
    int i;
    while (ptr1 < mid && ptr2 < to) {
        if (arr[ptr1] <= arr[ptr2]) {
            aux[wrtptr] = arr[ptr1];
            ptr1++;
        } else {
            aux[wrtptr] = arr[ptr2];
            ptr2++;
        }
        wrtptr++;
    }
    while (ptr1 < mid) {
        aux[wrtptr] = arr[ptr1];
        ptr1++;
        wrtptr++;
    }
    while (ptr2 < to) {
        aux[wrtptr] = arr[ptr2];
        ptr2++;
        wrtptr++;
    }
    for (i = 0; i < wrtptr; i++) {
        arr[from+i] = aux[i];
        print_list(arr, length);
    }
    free(aux);
    return 0;
}

int bottomup_merge_sort(int *arr, size_t length)
{
    int size = 2;
    int from;
    int mid;
    int to;
    while (size < length * 2) {
        for (from = 0; from < length; from += size) {
            mid = from + size / 2;
            to = from + size;
            if (mid >= length)
                mid = length;
            if (to >= length)
                to = length;
            merge(arr, from, mid, to, length);
        }
        size *= 2;
    }
    return 0;
}
