#include <stdlib.h>
#include <math.h>
#include "merge.h"
#include "../display/display.h"

static int merge(int *arr, int from, int mid, int to, size_t length)
{
    int *aux = (int*)calloc(to - from, sizeof(int));
    int ptr1 = from;
    int ptr2 = mid;
    int wrtptr = 0;
    int i;
    while (ptr1 < mid && ptr2 < to) {
        if (arr[ptr1] <= arr[ptr2]) {
            aux[wrtptr] = arr[ptr1];
            ptr1++;
        } else {
            aux[wrtptr] = arr[ptr2];
            ptr2++;
        }
        wrtptr++;
    }
    while (ptr1 < mid) {
        aux[wrtptr] = arr[ptr1];
        ptr1++;
        wrtptr++;
    }
    while (ptr2 < to) {
        aux[wrtptr] = arr[ptr2];
        ptr2++;
        wrtptr++;
    }
    for (i = 0; i < wrtptr; i++) {
        arr[from+i] = aux[i];
        print_list(arr, length);
    }
    free(aux);
    return 0;
}

int merge_sort(int *arr, int from, int to, size_t length)
{
    if (to - from <= 1)
        return 0;
    int mid = floor((from + to) / 2);
    merge_sort(arr, from, mid, length);
    merge_sort(arr, mid, to, length);
    return merge(arr, from, mid, to, length);
}
