#include <stdlib.h>
#ifndef PANCAKE_H
#define PANCAKE_H

int pancake_sort(int *arr, size_t length);

#endif // PANCAKE_H
