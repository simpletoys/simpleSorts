#include <stdlib.h>
#ifndef DOUBLESELECTION_H
#define DOUBLESELECTION_H

int double_selection_sort(int *arr, size_t length);

#endif // DOUBLESELECTION_H
