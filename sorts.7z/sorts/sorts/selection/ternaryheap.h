#include <stdlib.h>
#ifndef TERNARYHEAP_H
#define TERNARYHEAP_H

static int max_heapify(int *arr, size_t i, size_t length);

#endif // TERNARYHEAP_H
