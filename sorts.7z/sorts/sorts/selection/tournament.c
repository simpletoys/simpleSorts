#include <stdlib.h>
#include <math.h>
#include "tournament.h"
#include "../display/display.h"

static int *tree_build(int *arr, size_t length);
static int get_winner(int *tree, int *flags, int i);
static int pop_winner(int *tree, int *flags, int length);

static int *tree_build(int *arr, size_t length)
{
    int *tree = (int*)calloc(2*length-1, sizeof(int));
    int left;
    int right;
    int i = 0;
    for (i = 0; i < length; i++) {
        tree[i+length-1] = arr[i];
    }
    for (i = length-2; i > -1; i--) {
        left = 2*i+1;
        right = 2*i+2;
        if (tree[left] < tree[right]) {
            tree[i] = tree[left];
        } else {
            tree[i] = tree[right];
        }
    }
    return tree;
}

static int get_winner(int *tree, int *flags, int i)
{
    int left = 2*i+1;
    int right = 2*i+2;
    if (flags[left] == 1 && flags[right] == 1)
        return 0;
    if (flags[left] == 1)
        return tree[right];
    if (flags[right] == 1)
        return tree[left];
    if (tree[left] < tree[right])
        return tree[left];
    return tree[right];
}

static int pop_winner(int *tree, int *flags, int length)
{
    int i = 0;
    int winner = tree[0];
    int left;
    int right;
    while (2*i+2 < length) {
        left = 2*i+1;
        right = 2*i+2;
        if (flags[left] == 0 && tree[left] == winner) {
            i = left;
        } else if (flags[right] == 0 && tree[right] == winner) {
            i = right;
        } else {
            break;
        }
    }
    tree[i] = 0;
    flags[i] = 1;
    while (i > 0) {
        i = floor((i - 1) / 2);
        flags[i] = flags[2*i+1] * flags[2*i+2];
        tree[i] = get_winner(tree, flags, i);
    }
    return 0;
}

int tournament_sort(int *arr, size_t length)
{
    int *tree = tree_build(arr, length);
    int *flags = (int*)calloc(2*length-1, sizeof(int));
    int i = 0;
    for (i = 0; i < length; i++) {
        arr[i] = tree[0];
        print_list(arr, length);
        pop_winner(tree, flags, 2*length-1);
    }
    free(flags);
    free(tree);
    return 0;
}
