#include <stdlib.h>
#include "pancake.h"
#include "../display/display.h"

static int flip(int *arr, size_t from, size_t to);

static int flip(int *arr, size_t from, size_t to)
{
    int ptr1 = from;
    int ptr2 = to - 1;
    int tmp;
    while (ptr1 < ptr2) {
        tmp = arr[ptr1];
        arr[ptr1] = arr[ptr2];
        arr[ptr2] = tmp;
        ptr1++;
        ptr2--;
    }
    return 0;
}

int pancake_sort(int *arr, size_t length)
{
    int i;
    int j;
    int highest;
    for (i = length; i > 0; i--) {
        highest = 0;
        for (j = 0; j < i; j++) {
            if (arr[j] > arr[highest])
                highest = j;
        }
        flip(arr, 0, highest+1);
        print_list(arr, length);
        flip(arr, 0, i);
        print_list(arr, length);
    }
    return 0;
}
