#include <stdlib.h>
#include "cycle.h"
#include "../display/display.h"
int cycle_sort(int *arr, size_t length)
{
    size_t start = 0;
    size_t pos;
    int item;
    int tmp;
    size_t i;
    for (start = 0; start < length-1; start++) {
        pos = start;
        item = arr[start];
        for (i = start + 1; i < length; i++) {
            if (arr[i] < item) {
                pos++;
            }
            print_list(arr, length);
        }
        if (start == pos) {
            continue;
        }
        while (arr[pos] == item) {
            pos++;
            print_list(arr, length);
        }
        tmp = arr[pos];
        arr[pos] = item;
        item = tmp;
        print_list(arr, length);
        while (pos != start) {
            pos = start;
            for (i = start + 1; i < length; i++) {
                if (arr[i] < item) {
                    pos++;
                }
                print_list(arr, length);
            }
            while (arr[pos] == item) {
                pos++;
                print_list(arr, length);
            }
            tmp = arr[pos];
            arr[pos] = item;
            item = tmp;
            print_list(arr, length);
        }
    }
    return 0;
}
