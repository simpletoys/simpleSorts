#include <stdlib.h>
#include "doubleselection.h"
#include "../display/display.h"

int double_selection_sort(int *arr, size_t length)
{
    size_t ptr1 = 0;
    size_t ptr2 = length-1;
    size_t lowest;
    size_t highest;
    int highval;
    int lowval;
    size_t i;
    int tmp;
    while (ptr1 < ptr2) {
        lowest = ptr1;
        highest = ptr1;
        lowval = arr[ptr1];
        highval = arr[ptr1];
        for (i = ptr1; i < ptr2+1; i++) {
            if (arr[i] < arr[lowest]) {
                lowest = i;
                lowval = arr[lowest];
            }
            print_list(arr, length);
            if (arr[i] > arr[highest]) {
                highest = i;
                highval = arr[highest];
            }
            print_list(arr, length);
        }
        tmp = arr[ptr1];
        arr[ptr1] = arr[lowest];
        arr[lowest] = tmp;
        print_list(arr, length);
        if (arr[highest] == highval) {
            tmp = arr[ptr2];
            arr[ptr2] = arr[highest];
            arr[highest] = tmp;
            print_list(arr, length);
        } else {
            tmp = arr[ptr2];
            arr[ptr2] = arr[lowest];
            arr[lowest] = tmp;
            print_list(arr, length);
        }
        ptr1++;
        ptr2--;
    }
    return 0;
}
