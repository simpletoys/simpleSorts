#include <stdlib.h>
#ifndef MINHEAP_H
#define MINHEAP_H

int min_heap_sort(int *arr, int length);

#endif // MINHEAP_H
