#include <stdlib.h>
#ifndef WEAKHEAP_H
#define WEAKHEAP_H

int weak_heap_sort(int *arr, size_t length);

#endif // WEAKHEAP_H
