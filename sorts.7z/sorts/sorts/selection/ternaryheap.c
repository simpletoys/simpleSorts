#include <stdlib.h>
#include <math.h>
#include "ternaryheap.h"
#include "../display/display.h"

static int max_heapify(int *arr, size_t i, size_t length)
{
    int left;
    int mid;
    int right;
    int largest;
    int tmp;
    while (1) {
        left = 3*i+1;
        mid = 3*i+2;
        right = 3*i+3;
        largest = i;
        if (left < length && arr[left] > arr[largest])
            largest = left;
        if (mid < length && arr[mid] > arr[largest])
            largest = mid;
        if (right < length && arr[right] > arr[largest])
            largest = right;
        if (largest != i) {
            tmp = arr[largest];
            arr[largest] = arr[i];
            arr[i] = tmp;
            i = largest;
        } else {
            break;
        }
    }
    return 0;
}

int ternary_heap_sort(int *arr, int length)
{
    int i = 0;
    int tmp;
    for (i = floor(length / 3); i > -1; i--) {
        max_heapify(arr, i, length);
        print_list(arr, length);
    }
    for (i = length-1; i > 0; i--) {
        tmp = arr[0];
        arr[0] = arr[i];
        arr[i] = tmp;
        print_list(arr, length);
        max_heapify(arr, 0, i);
        print_list(arr, length);
    }
    return 0;
}
