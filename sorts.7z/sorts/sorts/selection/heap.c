#include <stdlib.h>
#include <math.h>
#include "heap.h"
#include "../display/display.h"

static int max_heapify(int *arr, size_t i, size_t length);

static int max_heapify(int *arr, size_t i, size_t length)
{
    size_t largest;
    size_t left;
    size_t right;
    int tmp;
    while (1) {
        left = 2*i+1;
        right = 2*i+2;
        largest = i;
        if (left < length && arr[left] > arr[largest]) {
            largest = left;
        }
        if (right < length && arr[right] > arr[largest]) {
            largest = right;
        }
        if (largest != i) {
            tmp = arr[largest];
            arr[largest] = arr[i];
            arr[i] = tmp;
            i = largest;
        } else {
            break;
        }
    }
    return 0;
}

int heap_sort(int *arr, int length)
{
    int i = 0;
    int tmp;
    for (i = floor(length / 2); i > -1; i--) {
        max_heapify(arr, i, length);
        print_list(arr, length);
    }
    for (i = length-1; i > 0; i--) {
        tmp = arr[0];
        arr[0] = arr[i];
        arr[i] = tmp;
        print_list(arr, length);
        max_heapify(arr, 0, i);
        print_list(arr, length);
    }
    return 0;
}
