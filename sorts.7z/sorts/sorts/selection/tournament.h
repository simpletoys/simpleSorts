#include <stdlib.h>
#ifndef TOURNAMENT_H
#define TOURNAMENT_H

int tournament_sort(int *arr, size_t length);

#endif // TOURNAMENT_H
