#include <stdlib.h>
#ifndef CYCLE_H
#define CYCLE_H

int cycle_sort(int *arr, size_t length);

#endif // CYCLE_H
