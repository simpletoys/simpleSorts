#include <stdlib.h>
#include "selection.h"
#include "../display/display.h"

int selection_sort(int *arr, size_t length)
{
    size_t i;
    size_t j;
    size_t lowest;
    int tmp;
    for (i = 0; i < length; i++) {
        lowest = i;
        for (j = i; j < length; j++) {
            if (arr[j] < arr[lowest]) {
                lowest = j;
            }
            print_list(arr, length);
        }
        tmp = arr[i];
        arr[i] = arr[lowest];
        arr[lowest] = tmp;
        print_list(arr, length);
    }
    return 0;
}
