#include <stdlib.h>
#include <math.h>
#include "weakheap.h"
#include "../display/display.h"

static int dist_anc(int *arr, int *flags, int i);
static int join(int *arr, int *flags, int i);
static int siftdown(int *arr, int *flags, size_t bound);

static int dist_anc(int *arr, int *flags, int i)
{
    int j = floor(i / 2);
    while ((i & 1) == flags[j])
        i = floor(i / 2);
    return floor(i / 2);
}

static int join(int *arr, int *flags, int i)
{
    int tmp;
    int j = dist_anc(arr, flags, i);
    if (arr[j] < arr[i]) {
        tmp = arr[j];
        arr[j] = arr[i];
        arr[i] = tmp;
        flags[i] = 1 - flags[i];
    }
    return 0;
}

static int siftdown(int *arr, int *flags, size_t bound)
{
    if (bound == 0)
        return 0;
    int i = 1;
    while (2*i < bound) {
        if (flags[i] == 1)
            i = 2*i+1;
        else
            i = 2*i;
    }
    while (i > 0) {
        join(arr, flags, i);
        i = floor(i/2);
    }
    return 0;
}

int weak_heap_sort(int *arr, size_t length)
{
    int *flags = (int*)calloc(length, sizeof(int));
    int i = 0;
    int tmp;
    for (i = length-1; i > 0; i--) {
        join(arr, flags, i);
        print_list(arr, length);
    }
    for (i = length-1; i > 0; i--) {
        tmp = arr[0];
        arr[0] = arr[i];
        arr[i] = tmp;
        print_list(arr, length);
        siftdown(arr, flags, i-1);
        print_list(arr, length);
    }
    return 0;
}
