#include <stdlib.h>
#ifndef SELECTION_H
#define SELECTION_H

int selection_sort(int *arr, size_t length);

#endif // SELECTION_H
