#include <stdlib.h>
#ifndef COMB_H
#define COMB_H

int comb_sort(int *arr, size_t length);

#endif // COMB_H
