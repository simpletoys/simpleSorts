#include <stdlib.h>
#include "llquick.h"
#include "../display/display.h"

int ll_partition(int *arr, size_t from, size_t to, size_t length)
{
    if (to - from <= 1)
        return 0;
    int pivot = arr[from];
    size_t ptr1 = from + 1;
    size_t ptr2 = from + 1;
    int tmp;
    while (ptr2 < to) {
        if (arr[ptr2] < pivot) {
            tmp = arr[ptr1];
            arr[ptr1] = arr[ptr2];
            arr[ptr2] = tmp;
            ptr1++;
            ptr2++;
        } else {
            ptr2++;
        }
        print_list(arr, length);
    }
    tmp = arr[from];
    arr[from] = arr[ptr1-1];
    arr[ptr1-1] = tmp;
    print_list(arr, length);
    return ll_partition(arr, from, ptr1-1, length) + ll_partition(arr, ptr1, to, length);
}
