#include <stdlib.h>
#ifndef LLQUICK_H
#define LLQUICK_H

int ll_partition(int *arr, size_t from, size_t to, size_t length);

#endif // LLQUICK_H
