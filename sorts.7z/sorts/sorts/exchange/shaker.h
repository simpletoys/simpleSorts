#include <stdlib.h>
#ifndef SHAKER_H
#define SHAKER_H

int shaker_sort(int *arr, size_t length);

#endif // SHAKER_H
