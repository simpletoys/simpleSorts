#include <stdlib.h>
#ifndef BUBBLE_H
#define BUBBLE_H

int bubble_sort(int *arr, size_t length);

#endif // BUBBLE_H
