#include <stdlib.h>
#ifndef CIRCLE_H
#define CIRCLE_H

static size_t power_2(size_t num);

static int circle(int *arr, size_t from, size_t to, size_t length, int swapped);

int circle_sort(int *arr, size_t length);

#endif //CIRCLE_H
