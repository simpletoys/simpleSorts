#include <stdlib.h>
#include "shaker.h"
#include "../display/display.h"

int shaker_sort(int *arr, size_t length)
{
    int swapped = 1;
    int tmp;
    int i;
    while (swapped) {
        swapped = 0;
        for (i = 0; i < length-1; i++) {
            if (arr[i] > arr[i+1]) {
                swapped = 1;
                tmp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = tmp;
            }
            print_list(arr, length);
        }
        for (i = length-2; i > -1; i--) {
            if (arr[i] > arr[i+1]) {
                swapped = 1;
                tmp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = tmp;
            }
            print_list(arr, length);
        }
    }
    return 0;
}
