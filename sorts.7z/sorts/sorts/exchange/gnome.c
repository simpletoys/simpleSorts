#include <stdlib.h>
#include "gnome.h"
#include "../display/display.h"

int gnome_sort(int *arr, size_t length)
{
    size_t i = 0;
    int tmp;
    while (i < length) {
        if (i > 0 && arr[i-1] > arr[i]) {
            tmp = arr[i];
            arr[i] = arr[i-1];
            arr[i-1] = tmp;
            i--;
        } else {
            i++;
        }
        print_list(arr, length);
    }
    return 0;
}
