#include <stdlib.h>
#include "quick.h"
#include "../display/display.h"

int lr_partition(int *arr, size_t from, size_t to, size_t length)
{
    if (to - from <= 1)
        return 0;
    int pivot = arr[from];
    size_t ptr1 = from+1;
    size_t ptr2 = to-1;
    int tmp;
    while (1) {
        while (arr[ptr1] <= pivot) {
            ptr1++;
            print_list(arr, length);
        }
        while (arr[ptr2] > pivot) {
            ptr2--;
            print_list(arr, length);
        }
        if (ptr1 >= ptr2)
            break;
        tmp = arr[ptr1];
        arr[ptr1] = arr[ptr2];
        arr[ptr2] = tmp;
        print_list(arr, length);
    }
    tmp = arr[from];
    arr[from] = arr[ptr1-1];
    arr[ptr1-1] = tmp;
    print_list(arr, length);
    return lr_partition(arr, from, ptr1-1, length) + lr_partition(arr, ptr1, to, length);
}
