#include <stdlib.h>
#ifndef ODDEVEN_H
#define ODDEVEN_H

int odd_even_sort(int *arr, size_t length);

#endif // ODDEVEN_H
