#include <stdlib.h>
#ifndef QUICK_H
#define QUICK_H

int lr_partition(int *arr, size_t from, size_t to, size_t length);

#endif // QUICK_H
