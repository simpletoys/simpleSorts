#include <stdlib.h>
#include "circle.h"
#include "../display/display.h"

static size_t power_2(size_t num)
{
    size_t pwr = 1;
    while (pwr < num)
        pwr <<= 1;
    return pwr;
}

static int circle(int *arr, size_t from, size_t to, size_t length, int swapped)
{
    if (to - from <= 1)
        return swapped;
    size_t mid = from + power_2(to - from) / 2;
    size_t ptr1 = mid - (to - mid);
    size_t ptr2 = to - 1;
    int tmp;
    while (ptr1 < ptr2) {
        if (arr[ptr1] > arr[ptr2]) {
            swapped = 1;
            tmp = arr[ptr1];
            arr[ptr1] = arr[ptr2];
            arr[ptr2] = tmp;
        }
        print_list(arr, length);
        ptr1++;
        ptr2--;
    }
    return circle(arr, from, mid, length, swapped) + circle(arr, mid, to, length, swapped);
}

int circle_sort(int *arr, size_t length)
{
    int swapped = 1;
    while (swapped) {
        swapped = circle(arr, 0, length, length, 0);
    }
    return 0;
}
