#include <stdlib.h>
#include "dualpivotquick.h"
#include "../display/display.h"

int dual_pivot_partition(int *arr, size_t from, size_t to, size_t length)
{
    if (to - from <= 1)
        return 0;
    int pivot1;
    int pivot2;
    size_t ptr1 = from + 1;
    size_t ptr2 = from + 1;
    size_t ptr3 = to - 2;
    int tmp;
    if (arr[from] > arr[to-1]) {
        tmp = arr[from];
        arr[from] = arr[to-1];
        arr[to-1] = tmp;
        print_list(arr, length);
    }
    pivot1 = arr[from];
    pivot2 = arr[to-1];
    while (ptr2 <= ptr3) {
        if (arr[ptr2] < pivot1) {
            tmp = arr[ptr1];
            arr[ptr1] = arr[ptr2];
            arr[ptr2] = tmp;
            ptr1++;
            ptr2++;
        } else if (arr[ptr2] > pivot2) {
            tmp = arr[ptr3];
            arr[ptr3] = arr[ptr2];
            arr[ptr2] = tmp;
            ptr3--;
        } else {
            ptr2++;
        }
        print_list(arr, length);
    }
    tmp = arr[from];
    arr[from] = arr[ptr1-1];
    arr[ptr1-1] = tmp;
    print_list(arr, length);
    tmp = arr[to-1];
    arr[to-1] = arr[ptr3+1];
    arr[ptr3+1] = tmp;
    print_list(arr, length);
    return dual_pivot_partition(arr, from, ptr1-1, length)
         + dual_pivot_partition(arr, ptr1, ptr3+1, length)
         + dual_pivot_partition(arr, ptr3+2, to, length);
}
