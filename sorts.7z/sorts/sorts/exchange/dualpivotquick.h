#include <stdlib.h>
#ifndef DUALPIVOTQUICK_H
#define DUALPIVOTQUICK_H

int dual_pivot_partition(int *arr, size_t from, size_t to, size_t length);

#endif // DUALPIVOTQUICK_H
