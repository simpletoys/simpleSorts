#include <stdlib.h>
#include <math.h>
#include "comb.h"
#include "../display/display.h"

int comb_sort(int *arr, size_t length)
{
    size_t i;
    size_t gapsize = floor(length / 1.3);
    int tmp;
    int swapped = 1;
    while (gapsize > 1) {
        for (i = 0; i < length-gapsize; i++) {
            if (arr[i] > arr[i+gapsize]) {
                tmp = arr[i];
                arr[i] = arr[i+gapsize];
                arr[i+gapsize] = tmp;
            }
            print_list(arr, length);
            gapsize = floor(gapsize / 1.3);
        }
    }
    while (swapped) {
        swapped = 0;
        for (i = 0; i < length-1; i++) {
            if (arr[i] > arr[i+1]) {
                swapped = 1;
                tmp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = tmp;
            }
            print_list(arr, length);
        }
    }
    return 0;
}
