#include <stdlib.h>
#include "../display/display.h"
#include "exchange.h"

int exchange_sort(int *arr, size_t length)
{
    size_t i;
    size_t j;
    int tmp;
    for (i = 0; i < length; i++) {
        for (j = i; j < length; j++) {
            if (arr[j] < arr[i]) {
                tmp = arr[i];
                arr[i] = arr[j];
                arr[j] = tmp;
            }
            print_list(arr, length);
        }
    }
    return 0;
}
