#include <stdlib.h>
#include "oddeven.h"
#include "../display/display.h"

int odd_even_sort(int *arr, size_t length)
{
    int swapped = 1;
    int tmp;
    size_t i;
    while (swapped) {
        swapped = 0;
        for (i = 0; i < length-1; i += 2) {
            if (arr[i] > arr[i+1]) {
                swapped = 1;
                tmp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = tmp;
            }
            print_list(arr, length);
        }
        for (i = 1; i < length-1; i += 2) {
            if (arr[i] > arr[i+1]) {
                swapped = 1;
                tmp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = tmp;
            }
            print_list(arr, length);
        }
    }
    return 0;
}
