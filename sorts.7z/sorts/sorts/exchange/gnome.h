#include <stdlib.h>
#ifndef GNOME_H
#define GNOME_H

int gnome_sort(int *arr, size_t length);

#endif // GNOME_H
