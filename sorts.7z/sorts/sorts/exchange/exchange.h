#include <stdlib.h>
#ifndef EXCHANGE_H
#define EXCHANGE_H

int exchange_sort(int *arr, size_t length);

#endif // EXCHANGE_H
