#include <stdlib.h>
#include <math.h>
#include "../display/display.h"

int shell_sort(int *arr, size_t length)
{
    int gapsize = floor(length / 2.3);
    int i;
    int j;
    int tmp;
    while (gapsize > 0) {
        for (i = gapsize; i < length; i++) {
            j = i;
            tmp = arr[i];
            while (j > gapsize - 1 && arr[j - gapsize] > tmp) {
                arr[j] = arr[j-gapsize];
                j -= gapsize;
                print_list(arr, length);
            }
            arr[j] = tmp;
            print_list(arr, length);
        }
        gapsize = floor(gapsize / 2.3);
    }
    return 0;
}
