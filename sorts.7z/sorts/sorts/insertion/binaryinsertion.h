#include <stdlib.h>
#ifndef BINARYINSERTION_H
#define BINARYINSERTION_H

int binary_insertion_sort(int *arr, size_t length);

#endif // BINARYINSERTION_H
