#include <stdlib.h>
#include <math.h>
#include "../display/display.h"

static int binary_search(int *arr, size_t range, int target);

static int binary_search(int *arr, size_t range, int target)
{
    int to = range-1;
    int from = 0;
    int mid;
    while (from <= to) {
        mid = floor((from + to) / 2);
        if (target < arr[mid])
            to = mid - 1;
        else
            from = mid + 1;
    }
    mid = floor((from + to) / 2);
    if (arr[mid] < target)
        return mid + 1;
    return mid;
}

int binary_insertion_sort(int *arr, size_t length)
{
    int i = 0;
    for (i = 0; i < length; i++) {
        int tmp = arr[i];
        int index = binary_search(arr, i, arr[i]);
        int j = i;
        for (j = i; j > index; j--) {
            arr[j] = arr[j-1];
            print_list(arr, length);
        }
        arr[index] = tmp;
        print_list(arr, length);
    }
    return 0;
}
