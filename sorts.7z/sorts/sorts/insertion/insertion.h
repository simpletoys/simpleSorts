#include <stdlib.h>
#ifndef INSERTION_H
#define INSERTION_H

int insertion_sort(int *arr, size_t length);

#endif // INSERTION_H
