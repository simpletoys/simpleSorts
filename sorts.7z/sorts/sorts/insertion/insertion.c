#include "../display/display.c"
#include "insertion.h"

int insertion_sort(int *arr, size_t length)
{
    int i = 0;
    int j;
    int tmp;
    for (i = 0; i < length; i++) {
        j = i;
        tmp = arr[j];
        while (j > 0 && arr[j-1] > tmp) {
            arr[j] = arr[j-1];
            print_list(arr, length);
            j--;
        }
        arr[j] = tmp;
        print_list(arr, length);
    }
    return 0;
}
