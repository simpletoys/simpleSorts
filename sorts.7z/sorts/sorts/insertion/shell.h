#include <stdlib.h>
#ifndef SHELL_H
#define SHELL_H

int shell_sort(int *arr, size_t length);

#endif // SHELL_H
